# Written case analysis — Foundations of Cybersecurity

Course ARC2-C105, summative written assessment, Form A. Time allowed: 60 minutes. Closed book except your own module notes. Answer in the spaces under each part; short bullet answers are expected, not essays. Every claim must point to the case text (quote it, or give the event number or log source).

Marked against `rubric.md` criteria C1–C6. Your result is recorded by your instructor; nothing in this course scores you automatically.

## Case brief — Harbourview Community Housing Co-operative

**System description.** Harbourview has 22 staff and manages 300 rental units. Tenant files (names, income statements and the bank details tenants use for rent payments) are kept on one file server, HV-FS-01. All staff are members of the group "Office", which has read and write access to every folder on the server. Two part-time IT volunteers share one administrator account, "hvadmin". Staff reach the file server from home through a remote-access portal on the internet that asks for a user name and a password. The finance officer keeps a payments spreadsheet in which she adds or changes supplier bank details, and she uploads the monthly payment file to the bank's online service, which releases transfers of up to $10,000 without a second approval. Nightly backups are copied to a USB disk that stays plugged into HV-FS-01. A managed security service watches sign-in and firewall logs and sends alerts by e-mail.

**Last month's audit.** Harbourview passed its annual privacy audit. The auditor confirmed that tenant files are encrypted at rest on HV-FS-01, that staff sign a confidentiality agreement each year and that the server cupboard is locked. The audit did not look at remote access or at backups.

**Timeline, 2026-11-03 (all times UTC).**

| Event | Time | What happened | Where it was observed |
|---|---|---|---|
| E1 | 08:40 | The finance officer, r.osei, receives an e-mail styled as a notice from the provincial rent-subsidy office. It links to a page that looks like the co-op's portal sign-in, and she enters her user name and password. | Mail gateway log; r.osei's own report at 15:00 |
| E2 | 11:05 | Successful sign-in to the remote-access portal as r.osei from 192.0.2.55, an address never before seen for any staff account. | Portal sign-in log |
| E3 | 11:09–11:31 | The r.osei account opens every top-level shared folder and lists the server names on the network. | HV-FS-01 file audit log |
| E4 | 11:42 | The "Tenant Files" folder, 2.1 GB, is uploaded to an external file-sharing service. | Firewall log |
| E5 | 12:10 | The bank account numbers of two suppliers are changed in the payments spreadsheet by the r.osei account. The next payment run is due on 2026-11-05. | HV-FS-01 file audit log |
| E6 | 14:30 | An IT volunteer disconnects HV-FS-01 from the network; staff work on paper for the rest of the day. | IT volunteer's note in the service desk ticket |

**Alerts from the managed security service.**

```
Alert 1   Rule:     Sign-in from new location            ID 50231
          Time:     2026-11-03 11:06 UTC
          Account:  r.osei (finance officer)
          Detail:   Successful remote-access portal sign-in from
                    192.0.2.55, never before seen for this account.
          Context:  r.osei badged into the office at 08:15 (building
                    access log). Her office workstation shows keyboard
                    activity from 11:00 to 11:30 (endpoint tool).

Alert 2   Rule:     Scheduled task created on server     ID 50219
          Time:     2026-11-03 01:34 UTC
          Host:     HV-FS-01
          Account:  hvadmin
          Detail:   New scheduled task "NightlyUSBCopy" runs a copy
                    script daily at 02:00.
          Context:  Change record CR-118, approved 2026-11-02, states
                    that an IT volunteer will replace the backup task on
                    HV-FS-01 on 2026-11-03 at about 01:30. The script
                    path in the alert matches the path in CR-118. The
                    sign-in came from the IT volunteers' workstation.
```

## Part 1 — Impact classification
For each event E1–E6, state the property or properties affected (confidentiality, integrity, availability) or "no impact yet / entry point", with one sentence that refers to what happened to the data or the service.

| Event | Property or properties | Justification |
|---|---|---|
| E1 | | |
| E2 | | |
| E3 | | |
| E4 | | |
| E5 | | |
| E6 | | |

## Part 2 — Risk and design principles
(a) Label the threat (source and event), at least two vulnerabilities, the impact and the likelihood, and then state the risk.

| Element | Your label, with the case evidence |
|---|---|
| Threat source | |
| Threat event | |
| Vulnerability 1 | |
| Vulnerability 2 | |
| Impact | |
| Likelihood | |
| Risk | |

(b) Give at least two principle findings (least privilege, defence in depth or fail-safe defaults). Each must name the principle, say "applied" or "missing", and point to the sentence in the system description.

| Principle | Applied or missing | Evidence from the description |
|---|---|---|
| | | |
| | | |

## Part 3 — Actor and intrusion mapping
(a) Classify the actor by motivation and capability. Cite the evidence for each, and use cautious language.

| Motivation evidence | Capability evidence |
|---|---|
| | |

Classification (one sentence):

(b) Map the adversary's actions to MITRE ATT&CK tactics. Only adversary actions are mapped.

| Event | Tactic | Evidence |
|---|---|---|
| | | |

Gaps (what the timeline does not tell you; record as unknown, do not invent):

## Part 4 — Access and authentication
(a) Classify the factor or factors used on the remote-access portal path and state whether it meets multi-factor authentication. Give the reason.

(b) State one separation-of-duties conflict in the case as a rule (static or dynamic), give the reason, and propose either a role change or a compensating control.

Rule:
Reason:
Role change or compensating control:

## Part 5 — Compliance and residual risk
Identify at least one risk that Harbourview's compliant control set leaves open. State it in the words threat, vulnerability, likelihood and impact, and explain specifically why passing the audit did not reveal it.

## Part 6 — Triage and escalation
(a) Write a triage note for each alert.

```
Alert:        [rule name and alert ID]
Disposition:  [true positive / false positive / benign true positive /
               uncertain - escalate]
Evidence:     [each fact, with where it was observed]
Reasoning:    [one or two sentences connecting evidence to decision]
Action:       [closed / escalated to Tier 2 / tuning request raised]
```

(b) Write the escalation note for the alert you escalate. It must state the finding, list each piece of evidence with its time and where it was observed, give a confidence level, list at least one thing you could not check, and recommend next steps. Keep observed facts and your interpretation visibly separate.

```
ESCALATION - Alert [ID] - Priority: [ ] - Confidence: [ ]
Finding:
Evidence (observed in):
Checked, nothing found:
Not checked:
Actions taken:
Recommended next steps:
Urgency:
```
