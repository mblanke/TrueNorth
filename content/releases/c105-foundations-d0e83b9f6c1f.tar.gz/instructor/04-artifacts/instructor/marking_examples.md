# Marking examples — ARC2-C105 written case analysis

INSTRUCTOR ONLY. One strong and one weak sample answer per criterion of `../rubric.md`, Form A (Harbourview, `../deliverable.md`). Samples are invented for calibration, not real student work. Marks are P/F per criterion; the proposed case PASS rule is C6 PASS and at least four of C1–C5 PASS (Standards to confirm).

## C1 — Impact classification (M01-O01)

Strong (PASS):
> E1 C — her password was given to an outside page; no tenant data touched yet, this is the entry point. E2 C — someone else is now inside her account, no data changed yet. E3 C (minor) — folder and server names were seen. E4 C — 2.1 GB of tenant files including bank details left the co-op; can't be un-read. E5 I — two suppliers' bank numbers were changed without authorisation, payments would go to the wrong place. E6 A — our own IT took the server offline, staff on paper.

Why PASS: all six correct, each justified by what happened to the data or service, and E6 recorded as an availability impact even though it was defensive.

Weak (FAIL):
> E1 phishing = C. E2 C. E3 C. E4 C. E5 C, the hacker saw the payments. E6 none, IT did the right thing.

Why FAIL: E5 is an integrity impact (data changed), and E6 is omitted as "none" although the rubric requires the defensive disconnection to be recorded as availability; only four of six correct, and no justifications refer to what happened to the data.

## C2 — Risk and design principles (M01-O02, M01-O03)

Strong (PASS):
> Threat source: a fraud-motivated outside group (adversarial). Threat event: using a captured password to get into the file server and change payments. Vulnerabilities: (1) portal is internet-facing with password only; (2) "Office" group can read/write every folder, so a finance login reaches tenant files. Impact: confidentiality of 300 households' files; integrity of supplier payments (up to $10,000 per transfer). Likelihood: high — these e-mails are common and this one worked. Risk: high, because both likelihood and impact are high.
> Least privilege — missing: "All staff are members of the group 'Office', which has read and write access to every folder". Defence in depth — missing: "Nightly backups are copied to a USB disk that stays plugged into HV-FS-01" (not independent). Defence in depth — applied: "A managed security service watches sign-in and firewall logs" (it raised Alert 1).

Why PASS: threat has source and event, two vulnerabilities, impact and likelihood separate from risk; three principle findings each with principle, applied/missing and a quoted sentence.

Weak (FAIL):
> The risk is phishing. The vulnerability is the hacker. Impact is high. They should use zero trust. Least privilege is missing.

Why FAIL: threat, vulnerability and risk are confused (phishing is the threat event, the hacker is the source); no likelihood; only one principle finding and it has no evidence; the recommendation is not actionable and is not what was asked.

## C3 — Actor and intrusion mapping (M02-O01, M02-O02)

Strong (PASS):
> Motivation evidence: supplier bank numbers changed two days before the payment run (E5); tenant files with bank details taken (E4). Capability evidence: lure tailored to a housing co-op (rent-subsidy notice) but a common password-capture method and a valid account used through a password-only portal; no custom tools described. Classification: likely financially motivated, low-to-moderate capability, consistent with an organised fraud group.
> E1 Credential Access — fake sign-in page captured her password. E2 Initial Access — valid account on the portal. E3 Discovery — opened every folder, listed servers. E4 Exfiltration — upload to file-sharing service. E5 Impact — payment data manipulated. (E6 is our action, not mapped.) Gaps: unknown how they chose r.osei; unknown whether they set up any persistence.

Why PASS: motivation and capability each evidenced, cautious language, five defensible mappings with evidence, defender action excluded, gaps recorded as unknown.

Weak (FAIL):
> A sophisticated foreign hacking group. E1 Initial Access, E2 Lateral Movement, E3 Collection, E4 Exfiltration, E5 Exfiltration, E6 Impact. They probably installed a backdoor.

Why FAIL: attribution without evidence, "sophisticated" from no evidence; E2, E3 and E5 mis-mapped; the defender's action (E6) mapped as adversary Impact; a persistence step is invented instead of recorded as a gap.

## C4 — Access and authentication (M03-O02, M03-O03)

Strong (PASS):
> (a) Portal asks for user name and password: the user name only identifies; the password is knowledge. One factor — not MFA.
> (b) Static rule: no user may both maintain supplier bank details and release payments. Reason: one person, or one captured account as on 2026-11-03, can redirect a payment and release up to $10,000 with no second person involved. Control: the bank requires a second approver for any new or changed payee; changed bank details are confirmed by phoning the supplier on a known number.

Why PASS: correct factor classification and MFA judgement with the reason; conflict stated as a rule in the page 5 form with reason and a workable control.

Weak (FAIL):
> (a) It is MFA because you need a user name and a password.
> (b) The finance officer has too much access, she should be watched more.

Why FAIL: a user name is not an authentication factor, and two knowledge items would not be MFA anyway; (b) names no conflicting pair, no rule form, and "watched more" is not a defined control.

## C5 — Compliance and residual risk (M05-O03)

Strong (PASS):
> Open risk: a password captured by a fake page is used from the internet to reach tenant files. Threat: fraud actor with credential-capture e-mails. Vulnerability: single-factor remote-access portal. Likelihood: high — common and it happened. Impact: confidentiality of tenant files, integrity of payments. The audit passed because it only checked encryption at rest, agreements and the locked cupboard; remote access was outside its scope, and encryption at rest does not protect data read through a valid login.

Why PASS: one open risk in all four terms and a specific reason the audit missed it (scope, and what encryption at rest actually covers).

Weak (FAIL):
> They were compliant but not secure because compliance is just a checkbox. They need better security.

Why FAIL: no specific risk, no threat/vulnerability/likelihood/impact, and no reason tied to the audit's scope or method.

## C6 — Triage and escalation (M06-O02, M06-O03)

Strong (PASS):
> Alert 50231 — True positive (likely). Evidence: 11:05 UTC portal sign-in as r.osei from 192.0.2.55, never seen before (portal sign-in log); r.osei badged in at 08:15 (building access log) and her office workstation was active 11:00–11:30 (endpoint tool); she reported entering her password on a look-alike page at 08:40 (mail gateway log, her report). Reasoning: the account is in use in the office and from outside at the same time. Action: escalated, high.
> Alert 50219 — Benign true positive. Evidence: CR-118 approves this task on HV-FS-01 at about 01:30 on 2026-11-03 (change system); alert at 01:34 with matching script path (alert detail); sign-in from the IT volunteers' workstation (alert context). Action: closed, no tuning; shared hvadmin means the individual volunteer cannot be confirmed.
> ESCALATION — Alert 50231 — Priority HIGH — Confidence high. Finding: r.osei's account was likely used by an unauthorised party after her password was captured; tenant files were uploaded externally and two suppliers' bank details were changed before the 2026-11-05 payment run. This suggests payment fraud. Evidence (observed in): 08:40 password entered on look-alike page (mail gateway log); 11:05 sign-in from 192.0.2.55 (portal sign-in log); 11:09–11:31 every top-level folder opened, servers listed (HV-FS-01 file audit log); 11:42 Tenant Files, 2.1 GB, uploaded to file-sharing service (firewall log); 12:10 two supplier bank numbers changed (HV-FS-01 file audit log). Not checked: whether the payment file has already gone to the bank; whether 192.0.2.55 used other accounts. Actions taken: none by me. Next steps: revoke sessions and reset password per playbook with approval; ask the bank to hold payments to the two suppliers and verify details by phone; preserve logs; find other recipients of the 08:40 e-mail. Urgency: payment run 2026-11-05; 300 households' data exposed.

Why PASS: both dispositions correct with three or more cited facts; the note has a finding, five timed and sourced evidence lines, confidence, things not checked and next steps; interpretation is labelled ("likely", "suggests").

Weak (FAIL):
> Alert 1: hacked, escalate. Alert 2: false positive, the rule is wrong, tune it.
> ESCALATION: The attacker from another country stole the tenant files and is stealing money. Please lock everything down ASAP and call the police.

Why FAIL: no cited evidence; Alert 2 is a benign true positive, not a rule error, and tuning would remove a useful Persistence signal; the note has no times, no sources, no confidence, nothing marked as unchecked, states guesses as facts ("another country") and recommends drastic action outside Tier 1 authority.
