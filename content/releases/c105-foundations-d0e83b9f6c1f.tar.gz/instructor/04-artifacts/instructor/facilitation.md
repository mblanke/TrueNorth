# Facilitation plan — ARC2-C105 Foundations of Cybersecurity

INSTRUCTOR ONLY. For an instructor who did not write the course. Draft for Standards review.

## The course at a glance

- Audience: first-year cyber-operator students, no security background. Instructor-led, foundation level, theory only: no lab, no live tools.
- Six modules of 150 minutes each, 900 minutes (15 h) in total. Every module has the same split, taken from the outline and the course YAML (`minutes_breakdown`): contact 45, reading 40, practice 45, assessment 20.
- Each module has five pages. Every page ends with a "Check yourself" task; the case-based ones are the module's three practice tasks. Expected answers: `answer_key.md` section 2.
- Assessment block (20 min) = Quiz (5 items, 10 min, pass 70 %) + 10 min banked. The six banked blocks make one 60-minute written case analysis (`../deliverable.md`) sat after the Module 6 quiz. Marking: `../rubric.md` and `marking_examples.md`.
- Retests: `../variant_B/assessment.md`. Do not show Form B before Form A has been sat.
- Source gaps named on the pages (not in the course reference library): Saltzer and Schroeder's design principles (M1 p3), the Lockheed Martin kill chain paper (M2 p3), NIST SP 800-162 on ABAC (M3 p2), ISO/IEC 27001 (M5 p3). You may bring them as supplementary reading; do not assess on content only they contain.
- Language: always say "student". Keep to defensive, observable descriptions; the course contains no offensive technique and you should not add any.

## How each 150-minute module runs

| Block | Minutes | What happens |
|---|---|---|
| Reading | 40 | Students read pages 1–5 (assign before class, or run in class as silent reading). They attempt the non-case "Check yourself" tasks while reading. |
| Contact | 45 | Instructor-led: about 9 minutes per page — the key idea, the worked example, one discussion prompt. |
| Practice | 45 | The three case practice tasks, about 15 minutes each: 10 minutes in pairs, 5 minutes debrief against the expected answer. |
| Assessment | 20 | Quiz, 10 minutes, individual, closed book. Then 10 minutes banked for the written case analysis (in Module 6 these become the 60-minute sitting together with the other banked blocks). |

If you run reading before class, open the contact block with a two-minute "what was hardest?" poll and spend extra time there. Keep the practice debrief short: show the expected answer's must-include items, not a full model answer.

Running the quiz: one attempt per student; record the score on the rubric marking sheet. A student below 70 % sits the module's Form B quiz at a later session after reviewing the answer key rationale with you (not the Form B answers).

---

## Module 1 — Security Principles and the CIA Triad (M01-O01, M01-O02, M01-O03)

| Block | Minutes | Content |
|---|---|---|
| Reading | 40 | Pages 1–5 |
| Contact | 45 | 9 p1 CIA triad, unit newsletter case · 9 p2 three-question method, clinic scheduling example · 9 p3 least privilege, defence in depth, fail-safe defaults, print shop · 9 p4 reading method, Northgate · 9 p5 risk vocabulary, library example |
| Practice | 45 | 15 training database outage (p2) · 15 community radio station (p4) · 15 field laptop (p5) |
| Assessment | 20 | Quiz 1 (10) + 10 banked |

How to run it: build the habit of "event by event, from what happened to the data". Put the clinic timeline on the board and classify it live with the class before they try the training database case. For p4, insist every finding has principle + applied/missing + quoted evidence.

Likely misconceptions:
- Labelling the whole incident with its headline ("phishing = confidentiality").
- Not recording defensive actions (taking a server offline) as availability impact.
- Thinking an accident is not a security impact.
- Calling uncertainty about data "no impact" instead of integrity.
- Calling the threat "the risk" (ransomware is the threat).
- Treating two identical controls as defence in depth.
- Assuming fail-safe always means "fail closed" (the fire-escape door).

Discussion prompts:
- In the newsletter case, which impact mattered most to the unit, and why is that not the same as "which came first"?
- Is a power cut a security incident? What does the CIA triad say?
- Northgate's VPN falls back to password-only "so people can keep working". Who made that decision, and should they have?
- Which part of risk = likelihood × impact does insurance change?

## Module 2 — Threat Actors and Attack Surfaces (M02-O01, M02-O02, M02-O03)

| Block | Minutes | Content |
|---|---|---|
| Reading | 40 | Pages 1–5 |
| Contact | 45 | 9 p1 motivation and capability, actor categories · 9 p2 two-column evidence table, common errors · 9 p3 kill chain and ATT&CK tactics · 9 p4 mapping method, dental group example · 9 p5 attack surface and four-factor ranking, veterinary clinic |
| Practice | 45 | 15 loyalty-points theft (p2) · 15 university research lab mapping (p4) · 15 accounting office ranking (p5) |
| Assessment | 20 | Quiz 2 (10) + 10 banked |

How to run it: model the two-column table on the ministries summary before students do the loyalty-points case. For ATT&CK, keep the fourteen tactic names visible; ask "what was the adversary trying to achieve at this moment?" for every event. Keep everything at the level of what happened and what records it leaves; do not teach how any technique is performed.

Likely misconceptions:
- Classifying the actor by the victim's sector, or by a headline's "sophisticated".
- Naming a country or group; first-year analysts classify by motivation and capability only.
- Mapping by the technical action instead of the goal (Discovery vs Collection; Credential Access vs Initial Access).
- Inventing steps to fill gaps instead of recording them as unknown.
- Treating ATT&CK as a strict sequence or a prediction.
- Forgetting the human surface (the receptionist) and physical surface in enumeration.
- Ranking on total score only, ignoring what lies behind the entry point.

Discussion prompts:
- Why might an actor pretend to be a hacktivist?
- In the dental group case, was the phishing e-mail Initial Access or Credential Access? Defend either.
- Who detected the research lab intrusion, and what does that tell you?
- What is the cheapest attack-surface reduction in the veterinary clinic?

## Module 3 — Access Control and Identity (M03-O01, M03-O02, M03-O03)

| Block | Minutes | Content |
|---|---|---|
| Reading | 40 | Pages 1–5 |
| Contact | 45 | 9 p1 identification, authentication, authorisation, accountability; joiner-mover-leaver · 9 p2 DAC, MAC, RBAC, ABAC and the four selection questions · 9 p3 factor categories, MFA rule, factor strength · 9 p4 five-step RBAC design, bookshop matrix · 9 p5 separation of duties, static vs dynamic, compensating controls |
| Practice | 45 | 15 municipal permit office model choice (p2) · 15 volunteer fire service paths (p3) · 15 community health clinic RBAC design (p4) plus one SoD rule for the student union (p5); give a pre-drawn matrix grid so the design fits, and debrief the SoD rule first if time is short |
| Assessment | 20 | Quiz 3 (10) + 10 banked |

How to run it: the clinic design is the longest task; give a matrix template with roles as rows and at least eight permission columns. For MFA, drill "categories, not steps" with the four designs on p3, then ask "is it MFA?" and "how strong is it?" as separate questions.

Likely misconceptions:
- Confusing authentication (who are you) with authorisation (what may you do).
- Counting prompts instead of factor categories (password + security question).
- Treating an e-mailed code as possession when the mailbox uses the same password.
- Choosing ABAC for everything because it is "most modern".
- One role per person; or a catch-all "Power User" role.
- Thinking recording and paying an invoice is the main conflict, missing creator vs payer.
- Treating a compensating control as if it prevents the conflict (it detects).

Discussion prompts:
- When should the bookshop move from pure RBAC to RBAC with ABAC conditions?
- Is the fire station's "inside the station, password only" rule reasonable? What does it trust?
- In the student union case, which step would reveal a fraudulent payment, and who does it?

## Module 4 — Applied Cryptography Concepts (M04-O01, M04-O02, M04-O03)

| Block | Minutes | Content |
|---|---|---|
| Reading | 40 | Pages 1–5 |
| Contact | 45 | 9 p1 what cryptography provides, symmetric and key management · 9 p2 asymmetric, hybrid TLS 1.3, decision guide · 9 p3 hashes, salted slow password hashing · 9 p4 MACs vs signatures and the four-mechanism table · 9 p5 certificates, chains, validation checks, Northwind trace |
| Practice | 45 | 15 regional blood bank (p2) · 15 club membership + overtime approval (p3, p4; split the pairs between the two) · 15 Lakeside certificate chain (p5) |
| Assessment | 20 | Quiz 4 (10) + 10 banked |

How to run it: no mathematics and no key tooling. Have students say the protection need first, then the choice, then the reason. Put the four-mechanism table (p4) on the board and leave it up for the whole module. Walk the Northwind chain check by check before students trace Lakeside.

Likely misconceptions:
- "Hashing is encryption" / "you can decrypt a hash".
- A hash next to a download proves who published it.
- A signed message is confidential.
- A salt must be secret, or makes a weak password strong.
- Using fast general hashes (SHA-256) for passwords is fine.
- Encrypting large files directly with RSA.
- Only the leaf's dates matter; a trusted root makes the chain valid.
- In Lakeside, missing that the "intermediate" is self-issued (really a private root).
- Clicking through a certificate warning is a fix.

Discussion prompts:
- Why does cryptography not give availability, and how does ransomware use that?
- Who needs whose public key in the blood bank case, for which need?
- Why should a public website and an internal staff system fix the Lakeside error differently?

## Module 5 — Security Governance and Frameworks (M05-O01, M05-O02, M05-O03)

| Block | Minutes | Content |
|---|---|---|
| Reading | 40 | Pages 1–5 |
| Contact | 45 | 9 p1 governance roles and the document hierarchy · 9 p2 five clues, six extracts · 9 p3 CSF 2.0 six functions, RMF, CIS · 9 p4 mapping method, water utility · 9 p5 compliance vs security, password-standard example |
| Practice | 45 | 15 transit authority extracts (p2) · 15 regional airport mapping (p4) · 15 clinic's annual audit (p5) |
| Assessment | 20 | Quiz 5 (10) + 10 banked |

How to run it: classify by verbs first, then specificity. For mappings, insist on one primary function per control and an interpreted gap, not just a count. Tie p5 back to Module 1's risk vocabulary: every open risk is stated as threat, vulnerability, likelihood, impact.

Likely misconceptions:
- Trusting the document's title over its language (extract E).
- "Must" alone makes something a standard (procedures say "must" too).
- Mapping by keyword ("backup policy" → Govern).
- Counting a control under two functions.
- Thinking Protect having the most controls is a problem.
- Treating an untested or out-of-date plan as full coverage.
- "Compliant means secure"; or the opposite, "compliance is useless".

Discussion prompts:
- Why does Govern sit at the centre of CSF 2.0?
- Who should approve a policy, a standard and a procedure, and why different people?
- The clinic passed its audit. Was the auditor wrong?

## Module 6 — Security Operations and the Analyst Role (M06-O01, M06-O02, M06-O03)

| Block | Minutes | Content |
|---|---|---|
| Reading | 40 | Pages 1–5 |
| Contact | 45 | 9 p1 SOC people, process, technology; tiers · 9 p2 alert workflow and owners, SLAs · 9 p3 outcomes, evidence, Alerts A and B · 9 p4 five-minute routine, triage note, thinking traps, alert fatigue · 9 p5 escalation note: finding, evidence, where observed |
| Practice | 45 | 15 payroll-clerk workflow (p2) · 15 Alert C triage and E/F triage note (p3, p4) · 15 SALES-LT-14 escalation note (p5) |
| Assessment | 20 | Quiz 6 (10) + 10 banked; then the 60-minute written case analysis (the six banked blocks) |

How to run it: everything here is on written alert summaries; there is no SIEM. Use the triage note and escalation note formats exactly. Read the poor and good Moreau notes aloud. Make students mark each line of their own note as "fact (source)" or "interpretation".

Likely misconceptions:
- "Looks fine" as triage; no cited evidence.
- Confusing benign true positive with false positive; tuning every benign true positive.
- Taking containment action beyond Tier 1 authority.
- Reading each alert alone instead of together (E and F).
- Treating "I found nothing" as proof, without saying what was checked.
- Escalation notes without times, time zones or sources; guesses stated as facts.

Discussion prompts:
- Is escalating early a weakness? When does it waste Tier 2's time?
- What would you expect to see if Alert C were real password guessing?
- Why does the SOC still want the scheduled-task rule after a benign true positive?

## Running the written case analysis (after Module 6)

- 60 minutes, individual, closed book except the student's own module notes. Hand out `../deliverable.md`; collect it at 60 minutes.
- Do not explain the case beyond reading it aloud once. You may clarify vocabulary that is not being assessed.
- Mark with `../rubric.md` criteria C1–C6 (each P/F, no partial credit inside a criterion) and the examples in `marking_examples.md`. Record on the marking sheet; Standards confirms.
- A student who fails sits Case Form B (`../variant_B/assessment.md`) after feedback on which criteria failed.
