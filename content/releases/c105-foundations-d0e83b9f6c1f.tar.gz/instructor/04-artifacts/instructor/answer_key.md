# Answer key — ARC2-C105 Foundations of Cybersecurity

INSTRUCTOR ONLY. Never give this file to students and never link it from a course page. Draft for Standards review; the course is a proposed, unsourced pilot.

Contents: (1) Quiz Form A, all 30 items, with rationale; (2) every "Check yourself" task on the 30 course pages (these are also the module practice tasks) with the expected answer; (3) Quiz Form B answers; (4) written case analysis model answers, Form A and Form B.

How to use the expected answers: they show what a correct answer contains. Accept other wording, and accept a different conclusion where the student's reasoning is sound and grounded in the case text (several pages say so explicitly, e.g. ATT&CK step 2 and containment order). "Must include" items are what a weak answer usually misses.

---

## 1. Quiz Form A (from `02-content/arc2-c105.yaml`)

Pass threshold 70 % per quiz (4 of 5).

### Quiz 1 — Security Principles and the CIA Triad

| Q | Answer | Objective | Rationale |
|---|---|---|---|
| 1 | B Integrity | M01-O01 | Values were changed without authorisation; nobody unauthorised read them (not C) and the system stayed usable (not A). |
| 2 | C Availability | M01-O01 | Taking a server offline denies authorised use; page 2 says defensive actions have impact too and must still be recorded. |
| 3 | A Fail-safe defaults | M01-O02 | A block-list that allows everything else is the opposite of default deny: a forgotten rule lets traffic through. |
| 4 | D Defence in depth | M01-O02 | A permanently connected backup is not an independent layer: whatever damages the server can damage the backup (Northgate example). |
| 5 | B A vulnerability | M01-O03 | An unsupported OS is a weakness a threat could exploit; the threat would be e.g. a ransomware campaign, and risk combines likelihood and impact. |

### Quiz 2 — Threat Actors and Attack Surfaces

| Q | Answer | Objective | Rationale |
|---|---|---|---|
| 1 | C Espionage, high capability | M02-O01 | Long quiet theft with no ransom = espionage; custom tools and return after removal = high capability (page 1 worked example). |
| 2 | D Victim's industry sector | M02-O01 | Page 2 "classifying by the victim" error: any sector can be hit by any actor; behaviour is the evidence. |
| 3 | A Discovery | M02-O02 | Listing accounts and shares is learning about the environment; Collection is gathering the target data itself. |
| 4 | B Post-entry detail, tactics repeat and overlap | M02-O02 | ATT&CK is finer-grained and not strictly ordered; both models are descriptive, not predictive, and neither attributes. |
| 5 | C Password-only RDP reachable from the internet | M02-O03 | Scores high on reachability (3), weak auth (2), full control (3); the printer is internal, e-mail has MFA, guest Wi-Fi is separated. |

### Quiz 3 — Access Control and Identity

| Q | Answer | Objective | Rationale |
|---|---|---|---|
| 1 | B Mandatory | M03-O01 | Fixed classification labels enforced centrally, owners cannot override: MAC. |
| 2 | C Attribute-based | M03-O01 | Care-team relationship, shift time and device are context attributes roles alone cannot express (page 2 hospital example). |
| 3 | D Not MFA, both knowledge | M03-O02 | MFA counts categories, not prompts; a security question is a second knowledge factor. |
| 4 | A Buyer + Bookkeeper | M03-O03 | One person could create a supplier and purchase order and then pay it; the static SoD rule on page 5. |
| 5 | B Privilege creep | M03-O03 | The mover step removed nothing; access reviews and mover processes prevent it. Not a compensating control or ABAC. |

### Quiz 4 — Applied Cryptography Concepts

| Q | Answer | Objective | Rationale |
|---|---|---|---|
| 1 | C Symmetric, key stored securely | M04-O01 | Same party encrypts and decrypts, large data, no distribution problem. |
| 2 | A Signature with publisher's private key | M04-O01 | Need is authenticity for many verifiers without a shared secret; a shared-key MAC would let any customer forge, a hash on the same page proves nothing about origin. |
| 3 | B Unique hashes, defeats precomputed tables | M04-O02 | Salt is not secret and does not make weak passwords strong; it forces per-user attack. |
| 4 | D Non-repudiation | M04-O02 | Both parties hold the key, so a third party cannot tell who made the MAC. |
| 5 | C Fails, expired certificate in chain | M04-O03 | Every certificate's dates are checked, intermediates included (Northwind example). |

### Quiz 5 — Security Governance and Frameworks

| Q | Answer | Objective | Rationale |
|---|---|---|---|
| 1 | B Standard | M05-O01 | Mandatory, specific and measurable (a number). |
| 2 | C Mislabelled: it is a standard | M05-O01 | "Must / must not" is mandatory; a guideline is recommended only, so the label would make it unenforceable. |
| 3 | A Detect | M05-O02 | No monitoring of logs or networks; every listed control is Protect, Recover, Respond or Govern. |
| 4 | D Govern | M05-O02 | CSF 2.0 places supply-chain risk management in Govern (page 3 table). |
| 5 | B Captured password used immediately from anywhere | M05-O03 | Length and rotation do not stop a typed-in password being captured; single-factor internet webmail is the open risk (page 5 worked example). |

### Quiz 6 — Security Operations and the Analyst Role

| Q | Answer | Objective | Rationale |
|---|---|---|---|
| 1 | C Tier 3 detection engineer | M06-O01 | Changing how the SOC detects is Tier 3 work; Tier 1 raises the tuning request. |
| 2 | B Acknowledge and take ownership | M06-O01 | Acknowledgement prevents duplicate work and starts the SLA clock; containment comes much later. |
| 3 | D False positive / benign, with tuning request | M06-O02 | Known destination, inside the window, normal volume (Alert A on page 3). |
| 4 | A Benign true positive | M06-O02 | The rule detected exactly what it was designed for; the activity was authorised. Not a rule error. |
| 5 | C Timed fact with source | M06-O03 | Only C gives time, action and where it was observed; B is an interpretation stated as fact. |

---

## 2. "Check yourself" tasks (module practice)

### Module 1

**Page 1 — CIA sentences for an everyday system.** Open answer. Expected: three sentences about one system, e.g. messaging app: C = a stranger reads my messages through a leaked backup; I = a message I sent is altered, or someone sends messages as me; A = the service is down during an emergency. Must include: the integrity example involves change (not just reading), the availability example involves no access.

**Page 2 — Training database outage (practice task).** Events in time order:
1. Debug log left on fills the disk; database unreachable from 16:00 Friday — availability (service down all weekend).
2. Technician deletes last month's exam results believing them temporary — integrity (authorised records destroyed without authorisation) and availability (results cannot be used).
3. Laptop copy found but completeness unknown — integrity (cannot trust the restored data is complete or correct; uncertainty is an integrity impact).
4. The copy on an instructor's laptop — confidentiality exposure (exam results held outside the controlled system, on a portable device).
Must include: an accident is still an impact; uncertainty belongs to integrity.

**Page 3 — Home Wi-Fi principles.** Open answer. Least privilege: guests get the Wi-Fi password, not the router admin password; missing → any guest can change router settings. Defence in depth: router firewall + device OS updates + account password + disk encryption; missing → one failure exposes files. Fail-safe defaults: new devices on a guest network or blocked until approved; missing → any device that joins can reach every other device.

**Page 4 — Community radio station (practice task).** At least four of:
- Least privilege — missing: all eleven volunteers know the single console password; everyone has full control.
- Accountability (related, accept under least privilege): the log shows the same user name for every change, so actions cannot be traced.
- Defence in depth — applied (partly): router rule blocks console access from outside the country — an extra layer, but weak (one rule, same password behind it).
- Fail-safe defaults — missing: after a reboot the router resets to factory rules that permit all traffic; the failure chooses the unsafe state.
- Defence in depth — applied: cloud backup with 30 days of versions is independent of the streaming server (unlike Northgate's attached disk); a ransomware event on the server would not reach older versions.
- Defence in depth — weak: the console is internet-reachable behind a single shared password.
Must include: at least one "applied" finding and the router-reboot finding.

**Page 5 — Field laptop (practice task).**
- Threat source: accidental (staff member losing the laptop); event: laptop lost or left behind, contact list read by whoever finds it. Accept adversarial theft as a second source.
- Vulnerability: disk not encrypted.
- Impact: confidentiality loss of 400 students' contact details; notification duty, complaints, media attention (reputation).
- Likelihood: raised — a similar laptop was lost last term and the laptop travels to schools.
- Risk: moderate to high; likelihood is raised and the impact affects 400 people and the organisation's reputation.
- Controls: full-disk encryption reduces the impact of loss (the laptop can still be lost, but the data cannot be read) — accept also "removes the vulnerability". Reduce likelihood: a checklist / tether / carry-only-what-you-need, or do not store the list on the laptop at all (removes the asset from the threat). Must say which part of the equation each changes.

### Module 2

**Page 1 — Municipal website defacement.** Motivation: ideology/protest (political message timed to a controversial vote). Capability: low to moderate (public two-week-old weakness, no custom research); four sites in an hour suggests automation or a scripted tool rather than a large team. Category: hacktivist. Evidence that would change it: data theft or continued quiet access after the defacement (points beyond protest), or a custom/unknown weakness (higher capability).

**Page 2 — Loyalty-points theft (practice task).**

| Motivation evidence | Capability evidence |
|---|---|
| Points converted to gift cards and sold online | Used e-mail/password pairs leaked two years earlier (no new weakness) |
| Thousands of accounts emptied for resale value | Rented pool of residential addresses (bought service, some organisation) |
| No public statement, no data published | Accounts with MFA untouched: actor did not adapt or persist past MFA |

Classification: financially motivated actor with low-to-moderate capability, consistent with an organised fraud/cybercriminal operation reusing leaked credentials. Sector sentence: retail is targeted by many kinds of actor; the money trail, not the sector, shows the motivation.

**Page 3 — Single events to tactics.** (a) Discovery — learning about the environment. (b) Persistence — survives reboots. (c) Exfiltration — moving data out (accept Collection for the compression step as a secondary tactic).

**Page 4 — University research lab (practice task).**

| # | Event | Tactic | Evidence |
|---|---|---|---|
| 1 | Found known, unpatched weakness in public web app | Reconnaissance (accept) | "found that the application had a known weakness" |
| 2 | Used it to run commands on the web server | Initial Access (exploit public-facing application); Execution | "used it to run commands" |
| 3 | Created a new local account | Persistence | creating an account to keep access |
| 4 | Obtained database password from configuration file | Credential Access | "password stored in the application's configuration file" |
| 5 | Connected from web server to internal database server | Lateral Movement | "connected to an internal database server" |
| 6 | Ran nightly queries against the research database | Collection | queries each night |
| 7 | Sent results to an external address | Exfiltration | "sent the results to an external address" |

Gaps (at least one): how commands were run and whether any were hidden (Defense Evasion unknown); how the channel to the external address was set up (Command and Control unknown); whether other servers were reached. Detection opportunities (at least two): the new local account creation; web server connecting to the database with the application credentials outside normal patterns; nightly outbound volume (which the provider noticed — the lab's own monitoring did not); unpatched public application found by vulnerability scanning. Must note: an outside party detected it, so internal monitoring was missing.

**Page 5 — Accounting office (practice task).** Example scoring (Reach / Auth / Priv / Weak):

| Entry point | R | A | P | W | Total |
|---|---|---|---|---|---|
| Internet file-sharing service, password only, two versions out of date | 3 | 2 | 3 | 3 | 11 |
| Receptionist resets passwords for any caller giving a staff name | 3 | 3 | 3 | 2 | 11 |
| Office Wi-Fi password visible from the street | 2 | 2 | 2 | 2 | 8 |
| Cloud e-mail with MFA | 3 | 1 | 2 | 1 | 7 |
| Staff laptops with full-disk encryption (physical) | 1 | 1 | 2 | 1 | 5 |

Top two: the file-sharing service (internet-reachable, single factor, known weakness, holds clients' tax documents) and the receptionist (anyone with a phone, no identity check, a reset gives full account access). Accept either order; accept small score differences when the reasoning is stated.

### Module 3

**Page 1 — Library card.** Showing the card: identification (and weak possession-based authentication). Authentication: usually nothing checks that the card belongs to you — weakest step. Authorisation: borrowing limits, fines, card status decide whether you may borrow. Accountability: the loan record ties the book to the card. Weakest: authentication; acceptable in a low-value setting, which the student should say.

**Page 2 — Municipal permit office (practice task).** RBAC: five stable job types map to roles; moving an intake clerk to inspector is one role change, not many permission edits; supports least privilege and SoD (e.g. intake vs approver). Rejected: MAC (no fixed classification labels, too rigid), DAC (owners deciding would spread access inconsistently), ABAC alone (access depends mainly on job, not context; more complex than needed). Accept RBAC with an ABAC condition if justified.

**Page 3 — Volunteer fire service (practice task).** Outside path: password (knowledge) + SMS code to phone (possession) = MFA. Inside path: password only = not MFA. Factor-strength weakness: SMS codes are a restricted option in SP 800-63-4 (number transfer, interception; codes can be relayed by a fake site). Non-factor weakness: shared station tablet that stays signed in — no accountability, anyone in the station acts as whoever is signed in; also the inside path trusts location.

**Page 4 — Community health clinic (practice task).** Roles: Receptionist, Nurse, Physician (Nurse + Prescriber, either one combined role or two roles held together — student states the choice), Office Manager (Billing), Staff (enter own timesheet), IT Provider. Matrix with at least eight permissions, e.g.: book appointments; update contact details; view clinical notes; update clinical notes; record vaccinations; prescribe medication; run billing; view billing reports; enter own timesheet; approve timesheets; manage system settings; manage user accounts. Least privilege for IT provider: system and account administration only, no clinical or billing permissions, so they can keep systems running without reading or changing patient data. Must not give the office manager clinical permissions or physicians approval of timesheets.

**Page 5 — Student union finances (practice task).** Conflict: the treasurer records income, pays expenses, adds payees and sends transfers up to $5,000, and also reconciles the bank statement — the step that would reveal a fraudulent payment. Rule (static): "No person may both add payees/send transfers and reconcile the bank statement." Reason: one person could add a fake payee, pay it and hide it in the reconciliation. Fix: the president or a second officer reconciles monthly (role change), or the bank requires a second approval for new payees and transfers over a threshold, or a monthly payment list reviewed by the president (compensating). Must notice: the $500 cheque rule is bypassed by the $5,000 online limit.

### Module 4

**Page 1 — College backups.** Symmetric is appropriate: the college's IT team encrypts and later decrypts; no one else needs the key; large data. Property: confidentiality at rest (against the cloud provider or anyone who reaches the storage). Key: not in the same cloud account as the backups (key next to data); held in a key management system or vault controlled by the college, with a recoverable escrow copy — if the only copy is lost, the backups are permanently unavailable.

**Page 2 — Regional blood bank (practice task).** Need 1, confidentiality per hospital: asymmetric to protect a per-file symmetric key with each hospital's public key, symmetric for the file (no shared secret per hospital, fits the small team). Need 2, authenticity and integrity: digital signature with the blood bank's private key; every hospital verifies with the one public key. Must use the hospital's public key for confidentiality and the blood bank's private key for signing.

**Page 3 — Club membership site (practice task).** Why so fast: unsalted SHA-256 means the same password always gives the same hash, so one precomputed table or one guess list cracks every account at once; SHA-256 is fast, so billions of guesses are cheap; many members used the suggested password, so one crack revealed many accounts. Salt: identical passwords would give different hashes, precomputed tables useless, each account attacked separately. Slow hashing: each guess costs far more, so far fewer passwords recovered in a day. Neither: a weak or suggested password can still eventually be guessed; and the club's suggested password practice itself.

**Page 4 — Overtime approval (practice task).** Option 1 (MAC): integrity and authenticity between the two key holders; no non-repudiation. Option 2 (signature): integrity, authenticity and non-repudiation. Dispute: Option 2 resolves it — only the supervisor's smart card could have produced a valid signature, and a neutral party can verify it with her public key; altered records fail verification. Option 1 cannot: payroll holds the same key and could have produced a valid MAC itself.

**Page 5 — Lakeside booking chain (practice task).** The "intermediate" is self-issued (issuer = subject = Lakeside Web CA): it is really a private root, not an intermediate. The chain ends there, and that root is not in the device's trust store (public roots only). Failing check: chain to a trust anchor (untrusted root). Dates, name and CA flags are fine. Fix: for a public website, obtain a certificate from a publicly trusted CA; for an internal staff-only system, distribute the Lakeside root to managed devices' trust stores. Clicking past the warning is not a fix.

### Module 5

**Page 1 — Your own rule.** Open answer. Check: the policy has no technology or numbers; the standard has something measurable; the procedure has numbered steps; the guideline uses "should/consider".

**Page 2 — Transit authority extracts (practice task).** A: guideline ("should be avoided", recommended). B: policy (intent "will protect", assigns accountability to the Director, no technology). C: standard (mandatory "must", specific and measurable: unused ports, 60 seconds). D: procedure (numbered steps for one task). E: mislabelled — titled "Guideline" but "must / must not" makes it a mandatory standard; it matters because a contractor could ignore a guideline without sanction, so the control on safety-critical signalling equipment would be unenforceable.

**Page 3 — Place in CSF 2.0 functions.** (a) Recover — makes recovery possible (accept Protect with reasoning). (b) Govern — an organisational expectation/policy (accept Identify, risk assessment, with reasoning). (c) Detect — monitoring for adverse events. (d) Protect — data security. (e) Respond — the incident has happened; communication during response (accept Recover communication if argued). (f) Identify — asset/data management (accept Govern if framed as setting the classification policy).

**Page 4 — Regional airport (practice task).**

| # | Control | Primary function |
|---|---|---|
| 1 | Badge access to server room | Protect |
| 2 | Central log platform, 24/7 outsourced alert review | Detect |
| 3 | Quarterly vulnerability scanning | Identify (risk assessment; accept Detect with reason) |
| 4 | Accounts disabled within 24 h of departure | Protect |
| 5 | IR team with tested ransomware playbook | Respond |
| 6 | Encrypted laptops | Protect |
| 7 | Steering committee chaired by the CEO | Govern |
| 8 | CIS-based hardened builds | Protect |
| 9 | Weekly FIDS backups on a disk in the same server room | Recover (weak) |

Tally: Govern 1, Identify 1, Protect 4, Detect 1, Respond 1, Recover 1 (weak). Least-covered: Recover — one weekly backup, of one system, in the same room as what it protects, never tested. Risk: a fire, flood or ransomware event in the server room could destroy the systems and their only backup together, so flight information displays could stay down for days; up to a week of changes could be lost.

**Page 5 — Clinic's annual audit (practice task).** At least one of:
- Reminder-service export: threat — an adversary or curious party on the transfer path, or a breach at the small outside company; vulnerability — unencrypted file transfer of patient names, phones and appointment types to a third party; likelihood — moderate (nightly, every night); impact — confidentiality of patient data, notification duty. Why missed: outside the audit's scope.
- Backups on the records server itself: threat — ransomware or a disk failure on the records server; vulnerability — backup is not independent of what it protects; likelihood — moderate/high for ransomware in healthcare; impact — availability and integrity: no recovery possible. Why missed: the audit checked that "a backup is taken", not that the clinic could restore from it.

### Module 6

**Page 1 — Who does it.** (a) Tier 3 detection engineer — changes detection logic. (b) Incident response lead with senior management, legal and communications — organisation-wide decision. (c) Tier 1 — clear, approved activity, closed with a note citing the approval. (d) Tier 2 — in-depth investigation and scoping.

**Page 2 — Payroll-clerk workflow (practice task).** 2 (SIEM rule fires — technology/Tier 3 rule) → 5 (Tier 1 acknowledges) → 3 (Tier 1 triage/enrichment) → 7 (Tier 1 escalates) → 4 (Tier 2 investigation) → 6 (Tier 2 containment with shift lead approval) → 1 (IR lead briefs senior management). Accept 1 before 6 if argued (major incident declared first), with the reason stated.

**Page 3 — Alert C, svc-print (practice task).** Disposition: false positive / benign activity caused by a configuration mismatch (accept "benign true positive" if argued: the rule correctly saw failed sign-ins). Evidence: password changed 23:30 under change record 4502; failures start 23:40, after the change; all 412 come from PRN-SRV-02, the print server configured with the account; no successful sign-ins; no other hosts. Expected for guessing: many sources or accounts, or a success — absent. Follow-up: IT updates the print-queue service with the new password (the service is probably broken) and the change process adds "update dependent services".

**Page 4 — Alerts E and F, SALES-LT-14 (practice task).**
```
Alert:        Office application started a command shell (E) and
              Connection to newly registered domain (F), SALES-LT-14
Disposition:  True positive (likely)
Evidence:     - 09:10 e-mail with spreadsheet attachment from external
                address to p.nguyen (mail gateway / user mailbox)
              - 09:12 spreadsheet app started a command shell, which
                started a scripting engine (endpoint tool, alert E)
              - 09:13 HTTPS to a domain registered three days ago,
                4 KB out, 380 KB in (alert F, network/proxy log)
              - No change records for SALES-LT-14 (change system)
Reasoning:    A spreadsheet has no normal need to start a shell; the
              sequence two and three minutes after an external
              attachment, then a download from a brand-new domain,
              fits Initial Access, Execution and Command and Control.
Action:       Escalated to Tier 2, high priority.
```
Must include at least four evidence items with sources and treat the two alerts together.

**Page 5 — SALES-LT-14 escalation note (practice task).** Must contain: Finding — SALES-LT-14 (p.nguyen) likely compromised through a malicious spreadsheet attachment, which ran a script and downloaded further content from a newly registered domain; same sender targeted four other sales staff. Evidence with time and source: 09:08 same external sender e-mailed four other sales staff (mail gateway log); 09:10 e-mail with attachment to p.nguyen (mail gateway log); 09:12 spreadsheet → command shell → scripting engine (endpoint process tree); 09:12 new file written to user's temporary folder (endpoint tool); 09:13 HTTPS to domain registered three days ago, 4 KB out / 380 KB in (alert F). Confidence: high or medium-high, with reason. Not checked: e.g. whether the four other recipients opened the attachment; contents of the new file; other connections from the laptop. Next steps: isolate SALES-LT-14 per playbook/with approval; check the four other recipients' endpoints; block the sender and domain; preserve the new file. Urgency: possible spread to four more staff. Facts and interpretation visibly separate; consistent time zone.

---

## 3. Quiz Form B answers (`04-artifacts/variant_B/assessment.md`)

| Quiz | Q1 | Q2 | Q3 | Q4 | Q5 |
|---|---|---|---|---|---|
| 1B | A | C | B | C | D |
| 2B | A | C | B | B | C |
| 3B | D | A | B | C | A |
| 4B | B | A | B | A | B |
| 5B | D | A | B | C | B |
| 6B | B | B | A | B | B |

Rationale, one line each:
- 1B: Q1 disclosure only → confidentiality. Q2 copy out = C, encryption = A; both must be recorded. Q3 access not removed at contract end → least privilege. Q4 failure leads to the unsafe state → fail-safe defaults. Q5 an active campaign is a threat (source and event), not a vulnerability.
- 2B: Q1 misuse of retained legitimate access for payment → financially motivated insider. Q2 persistence after removal shows resources and adaptation; victim sector and headlines are weak evidence. Q3 entry with a valid account → Initial Access (capture was Credential Access earlier). Q4 record unknowns as gaps, never invent. Q5 internet-reachable, single factor, known weakness, sensitive data.
- 3B: Q1 owner decides → DAC. Q2 stable job functions → RBAC. Q3 possession + knowledge → MFA. Q4 the e-mailed code depends on the same password → not meaningful MFA (Design A, page 3). Q5 enter own timesheet + approve timesheets is a classic conflicting pair.
- 4B: Q1 no shared secret and bulk data → hybrid. Q2 same party encrypts and decrypts → symmetric. Q3 a hash from the same page proves integrity against that page only. Q4 private-key signature gives integrity, authenticity, non-repudiation; not confidentiality. Q5 leaf name must match the site.
- 5B: Q1 recommended language → guideline. Q2 numbered steps for one task → procedure. Q3 nothing restores → Recover. Q4 restore testing serves recovery. Q5 narrow scope: compliance is necessary, not sufficient.
- 6B: Q1 scoping is Tier 2. Q2 escalation with a note follows triage when beyond authority. Q3 authorised activity correctly detected → benign true positive. Q4 implausible location plus immediate mail-forwarding rule → likely true positive, escalate. Q5 fact with time and source, interpretation labelled.

---

## 4. Written case analysis — model answers

### Form A — Harbourview (`04-artifacts/deliverable.md`)

**Part 1 (C1).**

| Event | Property | Justification |
|---|---|---|
| E1 | Confidentiality (credentials) / entry point | Her password was disclosed to the adversary's page; no tenant data affected yet. Accept "entry point, no impact yet" if the credential disclosure is noted. |
| E2 | Confidentiality (unauthorised access to the account); no data impact yet | An unauthorised party now holds a working session; accept "no impact yet". |
| E3 | Confidentiality (minor) | Folder and server names disclosed; nothing changed. |
| E4 | Confidentiality | 300 households' tenant files, including income and bank details, left the organisation; cannot be "un-read". |
| E5 | Integrity | Supplier bank details changed without authorisation; payments on 2026-11-05 would go to the wrong account. |
| E6 | Availability (defensive action) | The file server was deliberately taken offline; staff worked on paper. |

**Part 2 (C2).** Threat source: adversarial, financially motivated fraud actor. Threat event: using a captured password to read and alter payment data. Vulnerabilities (two or more): password-only internet-facing portal; "Office" group read/write on every folder; finance officer alone changes payee details and releases payments up to $10,000; backup disk always connected; shared "hvadmin" account. Impact: confidentiality of tenant files (300 households), integrity of supplier payments (financial loss up to $10,000 per transfer), availability during the disconnection. Likelihood: high — credential-capture e-mails are common and it succeeded here. Risk: high (high likelihood and high impact).
Principle findings (two or more): least privilege missing — every staff member can read and write every folder, so the finance officer's account reached the Tenant Files folder; least privilege/accountability missing — shared "hvadmin"; defence in depth missing/weak — one password is the only layer between the internet and tenant files (encryption at rest does not help against a valid account); defence in depth weak — backup USB disk permanently plugged in; defence in depth applied — managed monitoring of sign-in and firewall logs (it did raise Alert 1); fail-safe defaults missing — access to every folder is granted by default rather than by explicit need.

**Part 3 (C3).** Motivation: financial — supplier bank details changed two days before a payment run (E5); tenant files including bank details taken (E4) could be sold or used for fraud. Capability: low to moderate — a lure tailored to a housing co-op (rent-subsidy notice) shows some research, but the method is common credential capture and use of a valid account through a password-only portal; no custom tools or unknown weaknesses described. Classification: financially motivated actor with low-to-moderate capability, consistent with an organised fraud group. No country or named group.
Mapping: E1 Credential Access (fake sign-in page captured a password; accept "Initial Access preparation" if explained); E2 Initial Access (valid account on the remote-access portal); E3 Discovery (opened folders, listed servers); E4 Exfiltration (upload to file-sharing service; accept Collection as secondary); E5 Impact (data manipulation of payment details). E6 is the defender's action and must not be mapped. Gaps: how the adversary chose r.osei and the lure (Reconnaissance unknown); whether any persistence was set up; whether other accounts or the hvadmin account were used; whether the upload avoided detection.

**Part 4 (C4).** (a) Portal: user name (identification) and password (knowledge) only — single factor, not MFA. (b) Static rule: "No user may both maintain supplier bank details and release payments." Reason: one person (or one captured account, as here) can redirect a payment and release it with no second person involved; the bank releases up to $10,000 alone. Fix: move payment release to another person, or compensating — the bank requires a second approval for new or changed payees and over a threshold; call-back verification of changed bank details on a known number. Accept also: "IT volunteers administer accounts and would review their own logs; shared hvadmin" with a sound rule.

**Part 5 (C5).** Example: threat — credential-capture e-mail followed by use of the password from the internet; vulnerability — single-factor remote-access portal; likelihood — high (common, and it happened); impact — confidentiality of tenant files and integrity of payments. Why missed: the audit scope excluded remote access, and encryption at rest only protects against stolen disks, not against a valid user session. Second acceptable risk: ransomware encrypts HV-FS-01 and the attached USB disk together (backups out of scope; "a backup is taken" is not "we can recover").

**Part 6 (C6).**
```
Alert:        Sign-in from new location, 50231
Disposition:  True positive (likely)
Evidence:     - 11:05 UTC portal sign-in as r.osei from 192.0.2.55, never
                seen for any staff account (portal sign-in log)
              - r.osei badged into the office at 08:15 (building access
                log) and her office workstation was active 11:00-11:30
                (endpoint tool): she cannot be signing in from outside
              - 08:40 r.osei entered her password on a look-alike page
                (mail gateway log; her report)
Reasoning:    The same account is in use in the office and from an
              unknown external address at the same time, after a
              credential-capture e-mail.
Action:       Escalated to Tier 2, high priority.

Alert:        Scheduled task created on server, 50219
Disposition:  Benign true positive
Evidence:     - CR-118 approved 2026-11-02 for this task on HV-FS-01 at
                about 01:30 on 2026-11-03 (change system)
              - Alert at 01:34, script path matches CR-118 (alert detail)
              - Sign-in from the IT volunteers' workstation (alert context)
Reasoning:    The rule correctly saw a new scheduled task; it is the
              approved change, at the approved time and path.
Action:       Closed; no tuning (new server tasks are a Persistence
              signal). Note: the shared hvadmin account means we cannot
              confirm which volunteer made the change.
```
Escalation note must contain: finding (r.osei account used by an unauthorised party after credential capture; tenant files uploaded externally; two supplier bank details changed before the 2026-11-05 payment run — likely payment fraud and data theft); evidence lines E1–E5 each with time and source; confidence high, with reason (concurrent office activity); not checked (e.g. whether the payment file was already uploaded to the bank; whether 192.0.2.55 reached other accounts; mailbox rules); actions taken (none / file server disconnected 14:30 by IT if the note is written after E6); next steps (revoke sessions and reset r.osei's password per playbook, with approval; ask the bank to hold payments to the two suppliers and verify their details by phone on known numbers; preserve logs; check other recipients of the 08:40 e-mail); urgency (payment run 2026-11-05; 300 households' data exposed — likely notification duty, a decision for management).

### Form B — Northshore (`04-artifacts/variant_B/assessment.md`)

**Part 1.** E1 integrity (unauthorised program running on OFFICE-LT-03; system integrity lost) — accept "entry point" plus integrity of the host. E2 integrity of the host / confidentiality risk; accept "no data impact yet" with the C2 channel noted. E3 confidentiality (minor). E4 confidentiality (2,400 players' records including children's medical notes). E5 integrity (payee account changed before the 2026-11-12 run). E6 availability (defensive shutdown; registrations stopped).

**Part 2.** Threat: financially motivated adversary using a malicious attachment to reach and alter payment data. Vulnerabilities: staff are local administrators; "League Office" group read/write on every folder; the treasurer alone adds payees and sends up to $8,000; weekly backup to a NAS permanently mapped on NS-FS-02; password-only internet remote desktop. Impact: confidentiality of 2,400 players' records (minors, medical notes — high), integrity of referee payments, availability during shutdown. Likelihood: high. Risk: high. Principles: least privilege missing (local admin "so they can install software"; group access to every folder); defence in depth weak (NAS mapped on the server it protects); defence in depth applied (nightly off-site cloud backup of the finance folder; managed monitoring raised the alerts).

**Part 3.** Motivation: financial (payee change before a payment run). Capability: moderate (malicious document with script execution, fresh domain registered for the operation, several staff targeted). Mapping: E1 Initial Access (attachment) and Execution (shell and scripting engine); E2 Command and Control (newly registered domain, more received than sent); E3 Discovery; E4 Exfiltration; E5 Impact (data manipulation). E6 not mapped. Gaps: how the account reached NS-FS-02 (Lateral Movement or simply the user's existing access — unknown); Persistence unknown; what the 410 KB download was.

**Part 4.** Remote desktop: password only — knowledge, not MFA. SoD: "No person may both add payees and send transfers without a second approval" (static: separate payee maintenance from payment release; or dynamic: a payee added by the treasurer cannot be paid until the president approves). Reason: the annual review is too late to catch a redirected payment. Fix: bank dual approval for new payees and over a threshold; monthly payment list reviewed by the president.

**Part 5.** The compliance scope was card terminals and the payment page only. Open risk: malicious-attachment intrusion reaching the registration database (threat: fraud actor; vulnerability: local admin rights and broad folder access; likelihood: high; impact: confidentiality of minors' data). Or ransomware encrypting NS-FS-02 and the mapped NAS together. The assessment never looked at those systems.

**Part 6.** Alert 61407 (with 61408): true positive (likely) — evidence: 09:02 external spreadsheet attachment (mail gateway log); 09:03 spreadsheet → shell → scripting engine and new file in temp folder (endpoint tool); 09:04 HTTPS to four-day-old domain, 3 KB out / 410 KB in (proxy log); no change records. Escalate. Alert 61390: false positive / benign — contracted backup provider (asset register), inside 02:00–03:00 window, 6.2 GB within the 5.8–6.6 GB range; tuning request. Escalation note: finding, E1–E5 with times and sources, three other staff received the same e-mail (scope), confidence high, not checked (e.g. whether the other three opened it; whether the payment template was already used), next steps (isolate per playbook with approval — done at 11:30 if written after E6; check other recipients; hold the 2026-11-12 referee payment and verify the payee by phone; preserve the temp-folder file), urgency (payment run, minors' data).
