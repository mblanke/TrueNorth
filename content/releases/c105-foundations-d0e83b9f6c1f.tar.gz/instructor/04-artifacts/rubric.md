# Rubric — ARC2-C105 (Pass/Fail)
Critical events: none. ARC2-C105 is a theory course with no range module, so there are no critical events and no noise floor.
Non-tradeable: a FAIL on any module quiz (below its 70 % pass threshold) or on the written case analysis = course FAIL regardless of other work.
DRAFT for Standards. No crosswalk row is bound (course.po is null); the pass rule for the written case analysis below is an artifact-creator proposal, not a QSP standard.

## What is marked

| Part | Form | Standard | Source of the standard |
|---|---|---|---|
| Quizzes 1–6 | 5 multiple-choice items per module, about 10 min each | at least 70 % on each quiz (4 of 5) | `pass_threshold: 70` per module in the course YAML |
| Written case analysis | one short case (`04-artifacts/deliverable.md`), 60 min, six criteria C1–C6 | PASS = C6 PASS and at least four of C1–C5 PASS (proposed) | artifact-creator proposal; Standards to confirm |

Timing: each module's 20-minute assessment block is 10 min quiz + 10 min banked; the six banked blocks make the single 60-minute written sitting after Module 6. The outline's 900 minutes are unchanged.
Retest: `04-artifacts/variant_B/assessment.md` (second quiz form per module, alternate case, same criteria).

## Written case analysis — criteria (each P/F)

| # | Criterion | Evidence (deliverable section) | Objective ids | PASS standard | P/F |
|---|---|---|---|---|---|
| C1 | Classifies the CIA impact of each event in the case timeline | Part 1 — Impact classification | M01-O01 | At least 5 of the 6 timeline events carry the correct property (or "no impact yet / entry point") with a justification that refers to what happened to the data or service; the defensive disconnection is recorded as an availability impact. | |
| C2 | Labels the risk elements and finds principles applied or missing | Part 2 — Risk and design principles | M01-O02, M01-O03 | Threat given as source and event; at least two vulnerabilities; impact and likelihood stated separately from risk; at least two principle findings, each naming the principle, "applied" or "missing", and pointing to the case text. | |
| C3 | Classifies the actor and maps the intrusion to ATT&CK | Part 3 — Actor and intrusion mapping | M02-O01, M02-O02 | Motivation and capability each supported by at least one piece of case evidence, cautious language, no named-country attribution; at least five events mapped to a defensible tactic with evidence; at least one gap recorded as unknown, not invented. | |
| C4 | Evaluates the login design and states a separation-of-duties rule | Part 4 — Access and authentication | M03-O02, M03-O03 | Remote-access path classified by factor category and correctly judged not MFA; one separation-of-duties conflict stated as a static or dynamic rule, with the reason and a role change or compensating control. | |
| C5 | Identifies a risk the compliant control set leaves open | Part 5 — Compliance and residual risk | M05-O03 | At least one open risk stated with threat, vulnerability, likelihood and impact, and a specific reason the audit did not reveal it (scope, point-in-time or an assumption). | |
| C6 | Triages the two alerts and writes the escalation note | Part 6 — Triage and escalation | M06-O02, M06-O03 | Both alerts given the correct disposition with at least three cited facts each; the escalation note states the finding, at least four evidence lines each with a time and where it was observed, a confidence level, at least one thing not checked, and next steps; facts and interpretation kept visibly separate. | |

A criterion is FAIL when its standard is not met in full. Do not award partial credit inside a criterion; write the missing element in the comment column of the marking sheet. Marking examples: `04-artifacts/instructor/marking_examples.md`.

## Objective coverage

| Objective | Text | Evidence | P/F |
|---|---|---|---|
| M01-O01 | Classify the confidentiality, integrity or availability impact of each event in a written incident scenario | Quiz 1 Q1, Q2; case C1 | |
| M01-O02 | Identify where least privilege, defence in depth and fail-safe defaults are applied or missing in a system description | Quiz 1 Q3, Q4; case C2 | |
| M01-O03 | Distinguish threat, vulnerability, risk and impact by labelling each element of a short case | Quiz 1 Q5; case C2 | |
| M02-O01 | Classify the threat actors in published case summaries by motivation and capability | Quiz 2 Q1, Q2; case C3 | |
| M02-O02 | Map the phases of a published intrusion narrative to a recognised adversary-behaviour model | Quiz 2 Q3, Q4; case C3 | |
| M02-O03 | Enumerate the attack surface of a described system and rank its entry points by exposure | Quiz 2 Q5 | |
| M03-O01 | Select an access control model (DAC, MAC, RBAC or ABAC) for a given scenario and justify the choice | Quiz 3 Q1, Q2 | |
| M03-O02 | Classify the authentication factors in a login design and determine whether it meets multi-factor authentication | Quiz 3 Q3; case C4 | |
| M03-O03 | Design a role-based access model for a small organisation and identify one separation-of-duties conflict it must prevent | Quiz 3 Q4, Q5; case C4 | |
| M04-O01 | Select symmetric or asymmetric cryptography for a stated protection need and justify the choice | Quiz 4 Q1, Q2 | |
| M04-O02 | Identify which security properties a hash, a salted password hash and a digital signature each provide in a given case | Quiz 4 Q3, Q4 | |
| M04-O03 | Trace a certificate chain to its trust anchor and identify why a given certificate fails validation | Quiz 4 Q5 | |
| M05-O01 | Classify given governance documents as policy, standard, procedure or guideline | Quiz 5 Q1, Q2 | |
| M05-O02 | Map a set of described controls to the functions of a recognised cybersecurity framework and identify the least-covered function | Quiz 5 Q3, Q4 | |
| M05-O03 | Distinguish compliance from security by identifying a risk that a compliant control set leaves open in a case | Quiz 5 Q5; case C5 | |
| M06-O01 | Sequence the steps of a security operations centre alert workflow and assign each step to the responsible tier | Quiz 6 Q1, Q2 | |
| M06-O02 | Triage supplied written alert summaries as true or false positives, citing the supporting evidence for each | Quiz 6 Q3, Q4; case C6 | |
| M06-O03 | Write an escalation note that states the finding, its evidence and where the evidence was observed | Quiz 6 Q5; case C6 | |

Objectives evidenced by quiz items only (M02-O03, M03-O01, M04-O01, M04-O02, M04-O03, M05-O01, M05-O02, M06-O01) are also practised in the module "Check yourself" tasks, which are formative and not marked here.

## Marking sheet

| Student | Q1 | Q2 | Q3 | Q4 | Q5 | Q6 | C1 | C2 | C3 | C4 | C5 | C6 | Case | Course | Instructor initials / date | Comment |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| | | | | | | | | | | | | | | | | |

Summative: acknowledged by the instructor on the marking sheet above. This run has no range and no sensor stage, so no `05-sensor/validators/manual_ack_summative.md` exists; Standards confirms the acknowledgement.
Standards administers/scores per CFITES Vol 7. AI does not score summatives.
