# Variant B (retest) — Foundations of Cybersecurity

Course ARC2-C105. Retest forms for a student who did not pass on Form A. Same objectives, same pass thresholds, same criteria (`../rubric.md`); different case, different stems. Answers are in the instructor pack only.

Use: a student who fails a module quiz sits that module's Quiz Form B; a student who fails the written case analysis sits Case Form B. Do not give Form B to a student before they have sat Form A.

## Part I — Written case analysis, Form B (60 minutes)

Answer using the same six parts and the same answer layout as Form A (`../deliverable.md`, Parts 1–6). Every claim must point to the case text.

### Case brief — Northshore Youth Soccer League

**System description.** The league office has 9 staff and 2,400 registered players. The player registration records (names, dates of birth, guardians' phone numbers and e-mail addresses, and medical notes) are kept on one file server, NS-FS-02. All staff are members of the group "League Office", which has read and write access to every folder. Staff are local administrators on their office laptops "so they can install tournament software". The treasurer reaches her office PC from home through a remote-desktop service that is reachable from the internet and asks for a password only. In online banking the treasurer can add new payees and send transfers of up to $8,000 without anyone else approving; the president reviews the accounts once a year at the annual meeting. A weekly backup is copied to a network storage device on the same office network, which is permanently mapped as a drive on NS-FS-02. Separately, the finance folder is copied every night to the league's contracted cloud backup provider. A managed security service reviews endpoint, proxy and firewall alerts.

**Last month's assessment.** The league passed its payment-card compliance assessment. The assessment covered the card terminals used at registration days and the online payment page, which is run by a payment provider. Nothing else was in scope.

**Timeline, 2026-11-10 (all times UTC).**

| Event | Time | What happened | Where it was observed |
|---|---|---|---|
| E1 | 09:02 | The office administrator, m.haddad, opens a spreadsheet attachment called "Tournament schedule" from an external address. The spreadsheet application starts a command shell, which starts a scripting engine that writes a new file to her temporary folder. The same sender e-mailed three other staff at 09:00. | Mail gateway log; endpoint tool process tree for OFFICE-LT-03 |
| E2 | 09:04 | OFFICE-LT-03 makes an HTTPS connection to a domain registered four days earlier; 3 KB sent, 410 KB received. | Web proxy log |
| E3 | 09:40–10:15 | The m.haddad account lists the shared folders and the server names on the network. | NS-FS-02 file audit log |
| E4 | 10:22 | The "Registrations 2026" folder, 1.4 GB, is copied to an external storage service. | Firewall log |
| E5 | 10:50 | The payee account number in the referee-payments template is changed by the m.haddad account. The next referee payment run is on 2026-11-12. | NS-FS-02 file audit log |
| E6 | 11:30 | The IT contractor isolates OFFICE-LT-03 and shuts down NS-FS-02 for three hours; registrations stop for the morning. | IT contractor's ticket |

**Alerts from the managed security service.**

```
Alert 1   Rule:     Office application started a command shell   ID 61407
          Time:     2026-11-10 09:03 UTC
          Host:     OFFICE-LT-03, user m.haddad
          Detail:   Spreadsheet application started a command shell,
                    which started a scripting engine.
          Context:  E-mail with a spreadsheet attachment from an
                    external address delivered at 09:02 (mail gateway
                    log). Alert 61408 at 09:04: connection from
                    OFFICE-LT-03 to a newly registered domain. No change
                    records for OFFICE-LT-03.

Alert 2   Rule:     Large outbound data transfer                  ID 61390
          Time:     2026-11-10 02:15 UTC
          Host:     NS-FS-02
          Detail:   6.2 GB sent to 198.51.100.21 over 25 minutes.
          Context:  198.51.100.21 is the contracted cloud backup
                    provider (asset register). The nightly finance-folder
                    backup is scheduled 02:00-03:00. Transfer sizes over
                    the last 30 nights ranged from 5.8 to 6.6 GB.
```

Parts 1–6 are the same tasks as Form A: (1) classify E1–E6 by property; (2) label threat, vulnerabilities, impact, likelihood and risk, and give two principle findings; (3) classify the actor and map the adversary's actions to ATT&CK, with gaps; (4) classify the remote-desktop login by factor and judge MFA, and state one separation-of-duties rule; (5) identify a risk the compliant control set leaves open and why the assessment missed it; (6) triage both alerts and write the escalation note.

## Part II — Quiz Form B (one per module, 5 items, about 10 minutes, pass 70 %)

### Quiz 1B — Security Principles and the CIA Triad
1. A payroll spreadsheet is e-mailed by mistake to an external supplier. Nothing in it is changed. Which property has been harmed?
   A) Confidentiality  B) Integrity  C) Availability  D) Non-repudiation
2. Ransomware copies an office's files to an outside server and then encrypts them on site. Which classification is complete?
   A) Availability only  B) Confidentiality only  C) Confidentiality and availability  D) Integrity only
3. A contractor's account still works three months after the contract ended. Which principle is missing?
   A) Defence in depth  B) Least privilege  C) Open design  D) Fail-safe defaults
4. When the e-mail attachment scanner crashes, the mail system delivers messages unscanned so that staff are not delayed. Which principle does this design violate?
   A) Separation of duties  B) Least privilege  C) Fail-safe defaults  D) Economy of mechanism
5. "A phishing campaign is currently targeting colleges in the province." In risk vocabulary this statement describes:
   A) A vulnerability  B) An impact  C) A risk  D) A threat

### Quiz 2B — Threat Actors and Attack Surfaces
1. A former contractor uses a VPN account that was never disabled to copy a client list, then offers the list to a competitor for payment. Which classification best fits?
   A) Insider, financially motivated  B) Hacktivist seeking publicity  C) Nation-state espionage actor  D) Opportunistic actor seeking status
2. Which piece of evidence in a case summary most strongly indicates high capability?
   A) The victim is a defence contractor  B) A news report calls the attack "sophisticated"  C) The actor returned through a different route within days of being removed  D) A ransom note was left
3. An adversary signs in to an organisation's remote-access portal with a valid password captured earlier. Which ATT&CK tactic does the sign-in represent?
   A) Credential Access  B) Initial Access  C) Persistence  D) Discovery
4. An intrusion narrative jumps from Initial Access straight to Exfiltration. What should the analyst record?
   A) Lateral Movement, because it must have happened  B) A gap, noted as unknown  C) Nothing, because the narrative is unreliable  D) Impact, because data left the network
5. Using reachability, authentication, privilege and known weakness, which entry point is most exposed?
   A) A cloud e-mail service with multi-factor authentication  B) Staff laptops with full-disk encryption  C) An internet-facing file-sharing service, password only, two versions out of date  D) A guest Wi-Fi network separated from the office network

### Quiz 3B — Access Control and Identity
1. In a student club's photo-sharing service, each member decides who may see the albums they create. Which access control model is this?
   A) Mandatory  B) Attribute-based  C) Role-based  D) Discretionary
2. A permit office has forty staff in five stable job types, and people sometimes move between types. Which model fits best?
   A) Role-based  B) Mandatory  C) Discretionary  D) Attribute-based with one policy per person
3. A workstation login requires a badge tap and a six-digit PIN. Does it meet multi-factor authentication?
   A) No, because both are knowledge factors  B) Yes: possession and knowledge  C) Only if a fingerprint is added  D) No, because one device checks both
4. A login asks for a password and then a code e-mailed to the user's work mailbox, which is protected by the same password. What is the best judgement?
   A) MFA: knowledge and possession  B) MFA, because there are two steps  C) Not meaningful MFA: both steps depend on knowing the password  D) MFA if the code expires within five minutes
5. In a clinic's role design, which assignment would break a static separation-of-duties rule?
   A) The office manager, who approves timesheets, also holds a role that lets her enter her own timesheet  B) A nurse records vaccinations  C) A receptionist updates patient contact details  D) The IT provider manages accounts but has no clinical access

### Quiz 4B — Applied Cryptography Concepts
1. A field team must send large daily reports to headquarters over the internet and has never shared a secret key with headquarters. Which choice fits best?
   A) Symmetric encryption with a key e-mailed in advance  B) Asymmetric encryption to protect a per-report symmetric key, symmetric encryption for the report  C) A salted hash of each report  D) A MAC with a key shared with headquarters
2. A laptop user wants the disk protected if the laptop is lost; only she will ever unlock it. Which choice fits best?
   A) Symmetric full-disk encryption  B) A digital signature over the disk  C) A public SHA-256 hash of the disk  D) Asymmetric encryption with a new key pair per file
3. A downloaded firmware file's SHA-256 hash matches the hash on the vendor's download page. What has been established?
   A) The vendor created the file  B) The file matches what the page lists; not who published it  C) The file is confidential  D) The vendor cannot deny publishing it
4. A supervisor signs each overtime approval with a private key held on her smart card. Which properties does the signature provide?
   A) Integrity, authenticity and non-repudiation  B) Confidentiality only  C) Integrity only  D) Confidentiality and non-repudiation
5. A user visits mail.example.ca. The certificate presented is for www.example.ca, every certificate in the chain is within its dates, and the chain ends at a trusted root. What happens?
   A) Validation succeeds because the root is trusted  B) Validation fails on the name match  C) Validation fails because the root is self-signed  D) Validation succeeds because the dates are valid

### Quiz 5B — Security Governance and Frameworks
1. "Staff should consider using a passphrase of four or more unrelated words." How should this be classified?
   A) Policy  B) Standard  C) Procedure  D) Guideline
2. "1. Export the current rule set. 2. Compare it with last month's export. 3. Report exceptions to the network manager." How should this be classified?
   A) Procedure  B) Policy  C) Guideline  D) Standard
3. An organisation's controls are badge access, encrypted laptops, MFA, hardened builds, training, central log monitoring and an incident response team. Nothing is said about backups or restoring systems. Which CSF 2.0 function is least covered?
   A) Detect  B) Recover  C) Protect  D) Respond
4. Under CSF 2.0, testing that backups can actually be restored serves which function most directly?
   A) Protect  B) Govern  C) Recover  D) Identify
5. A shop fully meets a payment-card standard whose scope is its till systems. Its engineering file server is out of scope and two years behind on patches. What is the best statement?
   A) The shop is secure because it is compliant  B) Compliance leaves the risk on the out-of-scope server open  C) The file server is compliant because the shop passed  D) The standard should be ignored

### Quiz 6B — Security Operations and the Analyst Role
1. In a typical tiered SOC, who works out which other computers an infected laptop communicated with?
   A) Tier 1 triage analyst  B) Tier 2 incident analyst  C) System owner  D) Senior management
2. Triage shows an alert is suspicious and beyond Tier 1's authority. What is the next step?
   A) Close it with a note  B) Escalate it with an escalation note  C) Disable the account without approval  D) Wait for lessons learned
3. A password-guessing alert fires against a test account. The activity matches an entry on the approved list of planned test activity. How is it best labelled?
   A) Benign true positive  B) False negative  C) True positive; escalate  D) True negative
4. At 02:00 an account signs in from a country never seen for it, with no travel recorded, and within minutes creates a rule forwarding mail to an external address. What is the best triage outcome?
   A) False positive; close  B) Likely true positive; escalate  C) True negative  D) Benign true positive; tune the rule
5. Which escalation note line best separates fact from interpretation and gives the source?
   A) "The adversary is in another country."  B) "Sign-in from 203.0.113.77 at 03:17 UTC (webmail sign-in log); this suggests an unauthorised party."  C) "Looks hacked."  D) "Please check ASAP."
